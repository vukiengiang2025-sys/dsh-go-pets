DSH-Go Mascot Reference Pack
===========================

Included: 3 generated visual concept sheets for the DSH-Go mascot and its 12 animation states.

IMPORTANT:
These are concept/reference sheets, not production-ready transparent sprite frames. They contain backgrounds and composite poses and should not be blindly cropped into runtime assets.

Suggested target structure:
art/may/
  idle.png
  thinking.png
  working.png
  done.png
  error.png
  notification.png
  sleeping.png
  waking.png
  roam.png
  poke.png
  tickle.png
  drag.png

Suggested implementation prompt for your coding agent:
- Inspect the DSH-Go repository and existing art/may usage before changing anything.
- Preserve existing animation API, file naming, frame timing, dimensions, and build/tests.
- Use these sheets only as visual references. Produce clean individual PNG frames with transparent backgrounds, consistent mascot silhouette, no labels/background.
- Keep files small and animation rendering lightweight; do not add large dependencies.
- Create a backup and work on a separate branch; don't overwrite unrelated files.
- Run tests/build, report exact changes, and note any limitations.
